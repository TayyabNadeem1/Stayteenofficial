<?php session_start() ?>


<?php include('layouts/header.php');?>




<html>


<style>
* {
    margin: 0;
    padding: 0;
    text-align: center;
    /* box-sizing: border-box; */
}
    </style>
   <body>

   <section class="container-c">
      <div class="card">
      
      <div style="border-radius:200px; height:200px; width:200px; background: #F8FAF5; margin:0 auto;">
        <i class="checkmark">✓</i>
      </div>
      
      <h1>Success</h1> 
        <p>We received your purchase request;<br/>Thanks for trusting us</p>
      
    </div>
    

</section>
</body>


</html>


<?php include('layouts/footer.php');?>