<?php


$conn = mysqli_connect("localhost","root","","stayteen")
    or die("couldn't connect to database");

?>