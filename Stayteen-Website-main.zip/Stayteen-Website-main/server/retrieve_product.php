<?php


$conn = mysqli_connect("localhost","root","","stayteen")
    or die("couldn't connect to database");


$stmt = $conn->prepare("select * from products where product_id <=15 ");

$stmt->execute();

$featured_products = $stmt->get_result();




// Gold Section

$stmt_gold = $conn->prepare("select * from products where product_id >15 and product_id <=22");

$stmt_gold->execute();

$featured_products_gold = $stmt_gold->get_result();





// Charcoal

$stmt_charcoal = $conn->prepare("select * from products where product_id >22 and product_id <=28 ");

$stmt_charcoal->execute();

$featured_products_charcoal = $stmt_charcoal->get_result();



// Professional Series

$stmt_professional = $conn->prepare("select * from products where product_id >28 and product_id<33  ");

$stmt_professional->execute();

$featured_products_professional = $stmt_professional->get_result();



// $stmt_gold = $conn->prepare("select * from gold ");

// $stmt_gold->execute();

// $featured_products_gold = $stmt_gold->get_result();



?>